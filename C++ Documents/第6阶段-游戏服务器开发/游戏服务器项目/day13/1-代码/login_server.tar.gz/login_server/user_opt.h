#include <stdio.h>

void AddUser(const char *_name, const char *_password);
bool CheckUser(const char *_name, const char *_password_dgst);
