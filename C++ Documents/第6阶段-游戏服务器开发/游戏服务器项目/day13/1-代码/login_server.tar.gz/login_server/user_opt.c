#include <sys/types.h>
#include <sys/wait.h>

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
void AddUser(const char *_name, const char *_password)
{
    char buff[1024] = {0};

    sprintf(buff, "./add_user.sh %s %s", _name, _password);

    system(buff);
}
bool CheckUser(const char *_name, const char *_password_dgst)
{
    bool bRet = false;

    if (NULL == _password_dgst)
    {
        if (fork() > 0)
        {
            int iStatus = 0;
            wait(&iStatus);
            if (0 == iStatus)
            {
                bRet = true;
            }
        }
        else
        {
            execlp("./check_user.sh", "./check_user.sh", _name, NULL);
        }
    }


    return bRet;
}
