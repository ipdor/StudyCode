#!/bin/bash

cat userfile | grep -w $1 2>&1  > /dev/null
