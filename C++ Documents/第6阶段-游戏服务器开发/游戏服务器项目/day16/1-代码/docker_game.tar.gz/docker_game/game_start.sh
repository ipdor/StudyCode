#!/bin/bash

./game

while [ a == a ]
do
    sleep 10
    ps aux | grep -w game | grep -v grep
    if [ 0 -ne $? ]
    then
        # del redis' a piece of record
        redis-cli -h 192.168.64.148 del $MY_ROOM_NO 
        exit 0
    fi
done

