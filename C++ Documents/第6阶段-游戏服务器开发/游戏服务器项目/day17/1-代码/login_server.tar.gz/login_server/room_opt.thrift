service container_mng{
i32 create_room(1:i32 no)
}
